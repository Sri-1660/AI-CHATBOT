import os
import json
import logging
from typing import List
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

logger = logging.getLogger(__name__)

def load_and_process_documents(directory: str) -> List[Document]:
    """Load and process all documentation files."""
    documents = []
    file_count = 0
    section_count = 0
    
    # Verify directory exists
    if not os.path.isdir(directory):
        raise ValueError(f"Directory not found: {directory}")
    
    # Get absolute path for better error messages
    abs_directory = os.path.abspath(directory)
    logger.info(f"Processing documents from: {abs_directory}")
    
    # Check if directory is empty
    file_list = os.listdir(directory)
    if not file_list:
        raise ValueError(f"No files found in directory: {abs_directory}")
    
    for filename in file_list:
        if filename.endswith('.txt'):
            file_path = os.path.join(directory, filename)
            logger.info(f"Processing file: {filename}")
            file_count += 1
            
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    content = file.read()
                    
                    # Extract JSON content from files
                    if content.startswith('###'):
                        try:
                            json_start = content.find('[')
                            json_end = content.rfind(']') + 1
                            
                            if json_start == -1 or json_end == -1:
                                logger.warning(f"No JSON content found in {filename}")
                                continue
                                
                            json_content = content[json_start:json_end]
                            data = json.loads(json_content)
                            
                            for item in data:
                                # Create a document for each section
                                doc_content = (
                                    f"Title: {item.get('title', 'N/A')}\n"
                                    f"Section: {item.get('section', 'N/A')}\n"
                                    f"Content: {item.get('content', '')}"
                                )
                                metadata = {
                                    'source': filename,
                                    'id': item.get('id', ''),
                                    'section': item.get('section', '')
                                }
                                documents.append(Document(
                                    page_content=doc_content, 
                                    metadata=metadata
                                ))
                                section_count += 1
                        except json.JSONDecodeError as e:
                            logger.error(f"Error processing JSON in {filename}: {e}")
                            continue
            except Exception as e:
                logger.error(f"Error reading file {filename}: {e}")
                continue
    
    if not documents:
        raise ValueError("No valid documents were processed from the input files")
    
    logger.info(f"Processed {file_count} files with {section_count} sections")
    
    # Split documents into chunks
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=800,
        chunk_overlap=100
    )
    split_docs = text_splitter.split_documents(documents)
    
    logger.info(f"Split documents into {len(split_docs)} chunks")
    return split_docs