document.addEventListener('DOMContentLoaded', function() {
    const chatBox = document.getElementById('chatBox');
    const userInput = document.getElementById('userInput');
    const sendButton = document.getElementById('sendButton');
    
    // Check if system is initialized (button not disabled)
    if (sendButton.disabled) {
        return;
    }

    // Add user message to chat
    function addUserMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', 'user-message');
        messageElement.textContent = message;
        chatBox.appendChild(messageElement);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
    
    // Add bot message to chat
    function addBotMessage(message, sources) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', 'bot-message');
        
        // Preserve line breaks in the answer
        const formattedMessage = message.replace(/\n/g, '<br>');
        messageElement.innerHTML = formattedMessage;
        
        if (sources) {
            const sourcesElement = document.createElement('div');
            sourcesElement.classList.add('sources');
            sourcesElement.textContent = `Sources: ${sources}`;
            messageElement.appendChild(sourcesElement);
        }
        
        chatBox.appendChild(messageElement);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
    
    // Show loading indicator
    function showLoading() {
        const loadingElement = document.createElement('div');
        loadingElement.classList.add('message', 'bot-message');
        loadingElement.id = 'loadingMessage';
        loadingElement.innerHTML = 'Thinking... <span class="loading"></span>';
        chatBox.appendChild(loadingElement);
        chatBox.scrollTop = chatBox.scrollHeight;
        return loadingElement;
    }
    
    // Hide loading indicator
    function hideLoading(loadingElement) {
        if (loadingElement) {
            loadingElement.remove();
        }
    }
    
    // Send question to backend
    async function sendQuestion(question) {
        const loadingElement = showLoading();
        
        try {
            const response = await fetch('/ask', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ question: question })
            });
            
            const data = await response.json();
            
            if (data.error) {
                addBotMessage(`Error: ${data.error}`);
            } else {
                // Extract sources if present
                let sources = null;
                let answer = data.answer;
                
                const sourcesIndex = answer.indexOf('Sources: ');
                if (sourcesIndex !== -1) {
                    sources = answer.substring(sourcesIndex + 9);
                    answer = answer.substring(0, sourcesIndex);
                }
                
                addBotMessage(answer, sources);
            }
        } catch (error) {
            addBotMessage(`Sorry, I encountered an error: ${error.message}`);
        } finally {
            hideLoading(loadingElement);
        }
    }
    
    // Handle send button click
    sendButton.addEventListener('click', function() {
        const question = userInput.value.trim();
        if (question) {
            addUserMessage(question);
            sendQuestion(question);
            userInput.value = '';
        }
    });
    
    // Handle Enter key press
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const question = userInput.value.trim();
            if (question) {
                addUserMessage(question);
                sendQuestion(question);
                userInput.value = '';
            }
        }
    });
    
    // Focus input field on load
    userInput.focus();
});