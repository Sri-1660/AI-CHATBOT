from flask import Flask, render_template, request, jsonify
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain.chains import RetrievalQA
from litellm import completion
import os
import logging
import traceback

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Configuration
DATA_DIR = "data"
LLM_MODEL = "llama3"
qa_chain = None

def initialize_system():
    global qa_chain
    logger.info("Starting system initialization...")
    
    # 1. Check data directory
    if not os.path.exists(DATA_DIR):
        logger.error(f"Data directory '{DATA_DIR}' does not exist")
        return "Data directory not found"
    
    txt_files = [f for f in os.listdir(DATA_DIR) if f.endswith('.txt')]
    if not txt_files:
        logger.error(f"No text files found in '{DATA_DIR}'")
        return "No documents found in data directory"
    logger.info(f"Found {len(txt_files)} text files in data directory")
    
    # 2. Check Ollama
    try:
        logger.info("Testing Ollama connection...")
        llm_test = Ollama(model=LLM_MODEL)
        test_response = llm_test.invoke("Say 'OK'")
        if "OK" not in test_response:
            logger.warning("Unexpected Ollama test response")
        logger.info("Ollama connection successful")
    except Exception as e:
        logger.error(f"Ollama connection failed: {str(e)}")
        return f"Ollama connection error: {str(e)}"
    
    # 3. Load documents
    try:
        logger.info("Loading documents...")
        loader = DirectoryLoader(
            DATA_DIR, 
            glob="*.txt", 
            loader_cls=TextLoader,
            loader_kwargs={'encoding': 'utf-8'}
        )
        documents = loader.load()
        logger.info(f"Loaded {len(documents)} documents")
    except Exception as e:
        logger.error(f"Document loading failed: {str(e)}")
        return f"Document loading error: {str(e)}"
    
    # 4. Process documents
    try:
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )
        texts = text_splitter.split_documents(documents)
        logger.info(f"Split into {len(texts)} text chunks")
        
        embeddings = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2"
        )
        
        vectorstore = FAISS.from_documents(texts, embeddings)
        logger.info("Vector store created")
        
        llm = Ollama(model=LLM_MODEL, temperature=0.1)
        
        qa_chain = RetrievalQA.from_chain_type(
            llm=llm,
            chain_type="stuff",
            retriever=vectorstore.as_retriever(search_kwargs={"k": 3}),
            return_source_documents=True
        )
        logger.info("QA chain initialized successfully")
        return None  # No error
        
    except Exception as e:
        logger.error(f"Processing failed: {str(e)}")
        logger.error(traceback.format_exc())
        return f"Processing error: {str(e)}"

# Initialize on startup
init_error = initialize_system()

@app.route("/")
def home():
    return render_template("index.html", init_error=init_error)

@app.route("/ask", methods=["POST"])
def ask():
    if init_error:
        return jsonify({
            "answer": f"System initialization failed: {init_error}",
            "sources": []
        })
    
    if not qa_chain:
        return jsonify({
            "answer": "QA system not initialized",
            "sources": []
        })
    
    user_input = request.json["message"]
    
    try:
        result = qa_chain.invoke({"query": user_input})
        
        sources = set()
        for doc in result["source_documents"]:
            if "source" in doc.metadata:
                filename = os.path.basename(doc.metadata["source"])
                sources.add(filename)
        
        response = {
            "answer": result["result"],
            "sources": list(sources)
        }
    except Exception as e:
        response = {"answer": f"Error: {str(e)}", "sources": []}
    
    return jsonify(response)

@app.route('/health')
def health_check():
    return jsonify({
        'status': 'ok' if not init_error else 'error',
        'message': init_error or 'System ready',
        'ollama_model': LLM_MODEL,
        'documents': len(os.listdir(DATA_DIR)) if os.path.exists(DATA_DIR) else 0
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)